# BinaryTreeVisual



![image-20200221165800173](./resources/file.png)